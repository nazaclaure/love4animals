﻿// See https://aka.ms/new-console-template for more information
/*Console.WriteLine("Bienvenidos Al Sistema De Inventario De SafeWildLife");
Console.WriteLine();

bool on = true;

while (on)
{
    string menu = @"

    MENU INVENTARIO
1. Buscar Insumo
2. Salir
Selecciona una opción (1-1)
";

    Console.Write(menu);
   
   switch (Console.ReadLine())
   {
    case "1":
    Console.WriteLine("Buscar Insumo");
        break;
    case "2":
    on = false;
        break;

  
   }

   
}
*/
// See https://aka.ms/new-console-template for more information
Console.WriteLine("Bienvenidos Al Sistema De Inventario De SafeWildLife");
Console.WriteLine();

bool on = true;

while (on)
{
    string menu = @"

    MENU INVENTARIO
1. Búsqueda de Insumos
2. Ordenar Insumos
3. Buscar Órdenes
4. Programar Envíos
5. Contabilidad
6. Salir
Selecciona una opción (1-6)
";

    Console.Write(menu);

    switch (Console.ReadLine())
    {
        case "1":
            Console.WriteLine("Modulo: Búsqueda de Insumos");
            break;

        case "2":
            Console.WriteLine("Modulo: Ordenar Insumos");
            break;

        case "3":
            Console.WriteLine("Modulo: Buscar Órdenes");
            break;

        case "4":
            Console.WriteLine("Modulo: Programar Envíos");
            break;

        case "5":
            Console.WriteLine("Modulo: Contabilidad");
            break;

        case "6":
            Console.Write("¿Seguro que deseas salir? (S/N): ");
            string confirmacion = Console.ReadLine();

            if (confirmacion.ToUpper() == "S")
            {
                on = false;
                Console.WriteLine("Saliendo del sistema...");
            }
            break;

        default:
            Console.WriteLine("Error: Opción inválida");
            break;
    }

    Console.WriteLine();
}

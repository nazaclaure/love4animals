namespace Project1202.Dto;

public record OrderDto
(
    string OrderId,
    string User,
    DateTime Datetime,
    OrderProductDto Product,
    string OrderStatus,
    string Address,
    string Justification
);

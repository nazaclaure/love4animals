﻿using System.Net.Http.Json;
using Project1202.Dto;

Console.WriteLine("Bienvenidos al Sistema de Inventario de SafeWildlife");
Console.WriteLine();

bool on = true;
HttpClient http = new HttpClient();
//http.Timeout = TimeSpan.FromSeconds(10); //por si tarda mucho
//Console.OutputEncoding = System.Text.Encoding.UTF8; //para los caracteres extraños

while (on)
{
    string menu = """

    MENU DE INVENTARIO
    1. Búsqueda de Insumos
    2. Ordenar Insumos
    3. Buscar Órdenes
    4. Programar Envío
    5. Contabilidad
    6. Salir

    Selecciona una opción:
    """;

    Console.Write(menu);
    string? opcion = Console.ReadLine();

    switch (opcion)
    {
        case "1":
            Console.WriteLine("\nModulo: Búsqueda de Insumos");

            bool buscarMenu = true;

            while (buscarMenu)
            {
                string subMenu = """

                Buscar Insumo 
                1. Buscar producto por código de barras
                2. Buscar productos por categoría
                3. Volver al menú principal

                Selecciona una opción:
                """;

                Console.Write(subMenu);
                string? subOpcion = Console.ReadLine();

                switch (subOpcion)
                {
                    case "1":
                        Console.Write("Ingrese el código de barras: ");
                        string? productCode = Console.ReadLine();

                        if (string.IsNullOrWhiteSpace(productCode))
                        {
                            Console.WriteLine("Error: Código inválido.");
                            break;
                        }

                        UriBuilder uriBuilder = new UriBuilder("https://world.openfoodfacts.net")
                        {
                            Path = $"api/v2/products/{productCode}"
                        };
                        uriBuilder.Query = "fields=code,product_name,categories_tags,image_url,status_verbose";
                        string url = uriBuilder.ToString();

                        var httpResponse = await http.GetAsync(url);

                        if (!httpResponse.IsSuccessStatusCode)
                        {
                            Console.WriteLine("Error al consultar el producto.");
                            break;
                        }

                        var response = await httpResponse.Content.ReadFromJsonAsync<GetProductDto>();

                        if (response == null || response.Status != 1)
                        {
                            Console.WriteLine("Producto no encontrado.");
                            break;
                        }

                        Console.WriteLine("\nProducto encontrado:");
                        Console.WriteLine($"Código: {response.Code}");
                        Console.WriteLine($"Nombre: {response.Product.Product_name}");
                        Console.WriteLine($"Categorías: {string.Join(", ", response.Product.Categories_tags ?? new List<string>())}");
                        Console.WriteLine($"Imagen: {response.Product.Image_url}");
                        Console.WriteLine($"Estado: {response.Status_verbose}");

                        break;

                    case "2":
                        Console.Write("Ingrese la categoría (ej: snacks): ");
                        string? category = Console.ReadLine();

                        if (string.IsNullOrWhiteSpace(category))
                        {
                            Console.WriteLine("Error: Categoría inválida.");
                            break;
                        }

                        Console.WriteLine("Buscando productos, por favor espere...");

                        UriBuilder searchBuilder = new UriBuilder("https://world.openfoodfacts.net/api/v2/search");
                        searchBuilder.Query = $"fields=code,product_name,categories_tags,image_url&countries_tags_en=Bolivia&categories_tags={category}";
                        string searchUrl = searchBuilder.ToString();

                        var searchResponse = await http.GetAsync(searchUrl);

                        if (!searchResponse.IsSuccessStatusCode)
                        {
                            Console.WriteLine("Error al buscar productos.");
                            break;
                        }

                        var searchResult = await searchResponse.Content.ReadFromJsonAsync<SearchProductDto>();

                        if (searchResult == null || searchResult.Products == null || !searchResult.Products.Any())
                        {
                            Console.WriteLine("No se encontraron productos en esa categoría.");
                            break;
                        }

                        Console.WriteLine("\nProductos encontrados:\n");

                        foreach (var product in searchResult.Products)
                        {
                            Console.WriteLine("\nProducto encontrado:");
                            Console.WriteLine($"Código: {product.Code}");
                            Console.WriteLine($"Nombre: {product.Product_name}");
                            Console.WriteLine($"Categorías: {string.Join(", ", product.Categories_tags ?? new List<string>())}");
                            Console.WriteLine($"Imagen: {product.Image_url}");
                            Console.WriteLine("---------------------------");
                        }

                        break;

                    case "3":
                        buscarMenu = false;
                        break;

                    default:
                        Console.WriteLine("Error: Opción inválida.");
                        break;
                }
            }

            break;

        case "2":
            Console.WriteLine("\nModulo: Ordenar Insumos");

            //primero los datos pedir
            Console.Write("Nombre y apellido: ");
            string? userName = Console.ReadLine();
            Console.Write("Dirección de entrega: ");
            string? address = Console.ReadLine();
            Console.Write("¿Por qué necesitas este producto?: ");
            string? justification = Console.ReadLine();

            //verifico
            if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(address) || string.IsNullOrWhiteSpace(justification))
            {
                Console.WriteLine("Todos los campos son obligatorios.");
                break;
            }

            Console.Write("Código de barras del producto: ");
            string? orderCode = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(orderCode))
            {
                Console.WriteLine("Código inválido.");
                break;
            }


            Console.WriteLine("Verificando producto...");
            UriBuilder orderUri = new UriBuilder("https://world.openfoodfacts.net")
            {
                Path = $"api/v2/products/{orderCode}"
            };
            orderUri.Query = "fields=code,product_name";

            var orderHttpResponse = await http.GetAsync(orderUri.ToString());
            var orderProduct = await orderHttpResponse.Content.ReadFromJsonAsync<GetProductDto>();

            if (orderProduct == null || orderProduct.Status != 1)
            {
                Console.WriteLine("Ese producto no existe, verifica el código.");
                break;
            }

            Console.Write("¿Cuántos necesitas?: ");
            string? cantidadInput = Console.ReadLine();

            if (!int.TryParse(cantidadInput, out int cantidad) || cantidad <= 0)
            {
                Console.WriteLine("La cantidad no es válida.");
                break;
            }

            //muestro pa confirmar
            Console.WriteLine("\n¿Esto es lo que quieres pedir?");
            Console.WriteLine($"Nombre: {userName}");
            Console.WriteLine($"Producto: {orderProduct.Product.Product_name}");
            Console.WriteLine($"Código: {orderProduct.Code}");
            Console.WriteLine($"Cantidad: {cantidad}");
            Console.WriteLine($"Dirección: {address}");
            Console.WriteLine($"Justificación: {justification}");
            Console.Write("\nConfirmar (elegir entre S/N): ");
            string? confirmar = Console.ReadLine();

            if (confirmar?.ToUpper() != "S")
            {
                Console.WriteLine("Orden cancelada.");
                break;
            }

        
            OrderDto nuevaOrden = new OrderDto(
                OrderId: Guid.NewGuid().ToString(),
                User: userName,
                Datetime: DateTime.Now,
                Product: new OrderProductDto(
                    Code: orderProduct.Code,
                    Name: orderProduct.Product.Product_name,
                    Quantity: cantidad,
                    Total: null
                ),
                OrderStatus: "Pending",
                Address: address,
                Justification: justification
            );

            string archivo = "orders.json";
            List<OrderDto> ordenes = new List<OrderDto>();

            if (File.Exists(archivo))
            {
                string contenido = File.ReadAllText(archivo);
                ordenes = System.Text.Json.JsonSerializer.Deserialize<List<OrderDto>>(contenido) ?? new List<OrderDto>();
            }

            ordenes.Add(nuevaOrden);
            File.WriteAllText(archivo, System.Text.Json.JsonSerializer.Serialize(ordenes, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));

            Console.WriteLine("\nOrden guardada!");
            Console.WriteLine($"Tu número de orden es: {nuevaOrden.OrderId}");

            break;

        case "3":
            Console.WriteLine("\nModulo: Buscar Órdenes");

            if (!File.Exists("orders.json"))
            {
                Console.WriteLine("No hay órdenes registradas.");
                break;
            }

            string contenidoOrdenes = File.ReadAllText("orders.json");
            List<OrderDto> todasOrdenes = System.Text.Json.JsonSerializer.Deserialize<List<OrderDto>>(contenidoOrdenes) ?? new List<OrderDto>();

            if (!todasOrdenes.Any())
            {
                Console.WriteLine("No hay órdenes registradas.");
                break;
            }

            bool ordenesMenu = true;

            while (ordenesMenu)
            {
                string subMenuOrdenes = """

                Buscar Órdenes
                1. Ver todas las órdenes
                2. Ver detalle de una orden
                3. Volver al menú principal

                Selecciona una opción:
                """;

                Console.Write(subMenuOrdenes);
                string? opcionOrdenes = Console.ReadLine();

                switch (opcionOrdenes)
                {
                    case "1":
                        int paginaOrdenes = 1;
                        int porPagina = 20;
                        bool seguirViendo = true;

                        while (seguirViendo)
                        {
                            var ordenesPagina = todasOrdenes
                                .Skip((paginaOrdenes - 1) * porPagina)
                                .Take(porPagina)
                                .ToList();

                            if (!ordenesPagina.Any())
                            {
                                Console.WriteLine("No hay más órdenes.");
                                break;
                            }

                            Console.WriteLine($"\nMostrando página {paginaOrdenes}:\n");

                            foreach (var orden in ordenesPagina)
                            {
                                Console.WriteLine($"N° Orden: {orden.OrderId}");
                                Console.WriteLine($"Usuario: {orden.User}");
                                Console.WriteLine($"Fecha: {orden.Datetime:dd/MM/yyyy HH:mm}");
                                Console.WriteLine("---------------------------");
                            }

                            Console.Write("¿Ver más? (elegir entre S/N): ");
                            string? sig = Console.ReadLine();

                            if (sig?.ToUpper() != "S")
                                seguirViendo = false;
                            else
                                paginaOrdenes++;
                        }

                        break;

                    case "2":
                        Console.Write("Ingresa el ID de la orden: ");
                        string? idBuscado = Console.ReadLine();

                        if (string.IsNullOrWhiteSpace(idBuscado))
                        {
                            Console.WriteLine("ID inválido.");
                            break;
                        }

                        var ordenEncontrada = todasOrdenes.FirstOrDefault(o => o.OrderId == idBuscado);

                        if (ordenEncontrada == null)
                        {
                            Console.WriteLine("No se encontró ninguna orden con ese ID.");
                            break;
                        }

                        Console.WriteLine("\n--- Detalle de la Orden ---");
                        Console.WriteLine($"N° Orden: {ordenEncontrada.OrderId}");
                        Console.WriteLine($"Usuario: {ordenEncontrada.User}");
                        Console.WriteLine($"Fecha: {ordenEncontrada.Datetime:dd/MM/yyyy HH:mm}");
                        Console.WriteLine($"Estado: {ordenEncontrada.OrderStatus}");
                        Console.WriteLine($"Dirección: {ordenEncontrada.Address}");
                        Console.WriteLine($"Justificación: {ordenEncontrada.Justification}");

                        Console.WriteLine("\n--- Insumos ---");
                        Console.WriteLine("Código | Nombre | Cantidad | Total");
                        Console.WriteLine("---------------------------");
                        Console.WriteLine($"{ordenEncontrada.Product.Code} | {ordenEncontrada.Product.Name} | {ordenEncontrada.Product.Quantity} | {ordenEncontrada.Product.Total?.ToString() ?? "N/A"}");

                        break;

                    case "3":
                        ordenesMenu = false;
                        break;

                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }
            }

            break;

        case "4":
            Console.WriteLine("Modulo: Programar Envíos");
            break;

        case "5":
            Console.WriteLine("Modulo: Contabilidad");
            break;

        case "6":
            Console.Write("¿Seguro que deseas salir? (elegir entre S/N): ");
            string? confirmacion = Console.ReadLine();

            if (confirmacion?.ToUpper() == "S")
            {
                on = false;
                Console.WriteLine("Saliendo del sistema");
            }
            break;

        default:
            Console.WriteLine("Error: Opción inválida.");
            break;
    }

    Console.WriteLine();
}
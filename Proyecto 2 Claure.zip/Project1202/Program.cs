﻿using System.Net.Http.Json;
using Project1202.Dto;

Console.WriteLine("Bienvenidos al Sistema de Inventario de SafeWildlife");
Console.WriteLine();

bool on = true;
HttpClient http = new HttpClient();

while (on)
{
    string menu = """

    ===== MENU INVENTARIO =====

    1. Búsqueda de Insumos
    2. Ordenar Insumos
    3. Buscar Órdenes
    4. Programar Envíos
    5. Contabilidad
    6. Salir

    Selecciona una opción (1-6):
    """;

    Console.Write(menu);
    string? opcion = Console.ReadLine();

    switch (opcion)
    {
        case "1":
            Console.WriteLine("\nModulo: Búsqueda de Insumos");

            bool buscarMenu = true;

            while (buscarMenu)
            {
                string subMenu = """

                --- Buscar Insumo ---

                1. Buscar producto por código de barras
                2. Buscar productos por categoría
                3. Volver al menú principal

                Selecciona una opción (1-3):
                """;

                Console.Write(subMenu);
                string? subOpcion = Console.ReadLine();

                switch (subOpcion)
                {
                   
                    case "1":
                        Console.Write("Ingrese el código de barras: ");
                        string? productCode = Console.ReadLine();

                        if (string.IsNullOrWhiteSpace(productCode))
                        {
                            Console.WriteLine("Error: Código inválido.");
                            break;
                        }

                        try
                        {
                            string url = $"https://world.openfoodfacts.org/api/v2/product/{productCode}" +
                                         "?fields=code,product_name,categories_tags,image_url,status_verbose";

                            var response = await http.GetFromJsonAsync<GetProductDto>(url);

                            if (response != null && response.Status == 1)
                            {
                                Console.WriteLine("\nProducto encontrado:");
                                Console.WriteLine($"Código: {response.Code}");
                                Console.WriteLine($"Nombre: {response.Product.Product_name}");
                                Console.WriteLine($"Categorías: {string.Join(", ", response.Product.Categories_tags ?? new List<string>())}");
                                Console.WriteLine($"Imagen: {response.Product.Image_url}");
                                Console.WriteLine($"Estado: {response.Status_verbose}");
                            }
                            else
                            {
                                Console.WriteLine("Producto no encontrado.");
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Error al consultar el producto.");
                        }

                        break;

                  
                    case "2":
                        Console.Write("Ingrese la categoría (ej: snacks): ");
                        string? category = Console.ReadLine();

                        if (string.IsNullOrWhiteSpace(category))
                        {
                            Console.WriteLine("Error: Categoría inválida.");
                            break;
                        }

                        try
                        {
                            string searchUrl =
                                $"https://world.openfoodfacts.org/cgi/search.pl" +
                                $"?action=process" +
                                $"&tagtype_0=categories" +
                                $"&tag_contains_0=contains" +
                                $"&tag_0={category}" +
                                $"&fields=code,product_name" +
                                $"&json=1" +
                                $"&page_size=5";

                            var response = await http.GetFromJsonAsync<SearchProductDto>(searchUrl);

                            if (response != null && response.Products != null && response.Products.Any())
                            {
                                Console.WriteLine("\nProductos encontrados:\n");

                                foreach (var product in response.Products)
                                {
                                    Console.WriteLine($"Código: {product.Code}");
                                    Console.WriteLine($"Nombre: {product.Product_name}");
                                    Console.WriteLine("---------------------------");
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se encontraron productos en esa categoría.");
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Error al buscar por categoría.");
                        }

                        break;

                    case "3":
                        buscarMenu = false;
                        break;

                    default:
                        Console.WriteLine("Error: Opción inválida.");
                        break;
                }
            }

            break;

        case "2":
            Console.WriteLine("Modulo: Ordenar Insumos");
            break;

        case "3":
            Console.WriteLine("Modulo: Buscar Órdenes");
            break;

        case "4":
            Console.WriteLine("Modulo: Programar Envíos");
            break;

        case "5":
            Console.WriteLine("Modulo: Contabilidad");
            break;

        case "6":
            Console.Write("¿Seguro que deseas salir? (S/N): ");
            string? confirmacion = Console.ReadLine();

            if (confirmacion?.ToUpper() == "S")
            {
                on = false;
                Console.WriteLine("Saliendo del sistema...");
            }
            break;

        default:
            Console.WriteLine("Error: Opción inválida.");
            break;
    }

    Console.WriteLine();
}